/**
 * @file        index.ts
 * @description Single Import Point für alle Config Consumers
 * @version     1.0.0
 * @created     2026-01-07 19:45:00 CET
 * @updated     2026-01-07 19:45:00 CET
 * @author      agenten-koordinator
 *
 * @changelog
 *   1.0.0 - 2026-01-07 - Single import point für validated config
 */

/**
 * Export validated config
 */
export { appConfig } from './load';
export type { AppConfig, AppConfigTheme, AppConfigComponents } from './schema/config.schema';

/**
 * Export theme views (derived tokens)
 */
export { colorsConfig } from './theme/colors.config';
export { typographyConfig } from './theme/typography.config';
export { spacingConfig } from './theme/spacing.config';
export { iconsConfig } from './theme/icons.config';
export { breakpointsConfig } from './theme/breakpoints.config';
export { borderRadiusConfig } from './theme/borderRadius.config';
export { shadowsConfig } from './theme/shadows.config';

/**
 * Export component views (derived tokens)
 */
export { badgeConfig } from './components/badge.config';
export { buttonConfig } from './components/button.config';
export { dialogConfig } from './components/dialog.config';
export { dividerConfig } from './components/divider.config';
export { infoboxConfig } from './components/infobox.config';
export { inputConfig } from './components/input.config';
export { tableConfig } from './components/table.config';

/**
 * Export navigation config
 */
export { navigationConfig } from './navigation.config';
