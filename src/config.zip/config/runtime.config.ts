/**
 * @file        runtime.config.ts
 * @description Typed runtime config aus config-from-toml
 * @version     0.1.0
 * @created     2026-01-06 19:14:38 CET
 * @updated     2026-01-06 19:14:38 CET
 * @author      agenten-koordinator
 *
 * @changelog
 *   0.1.0 - 2026-01-06 - Initial scaffold
 */

import { configFromToml } from './generated/config-from-toml';

export const runtimeConfig = {
  app: configFromToml.app,
  server: configFromToml.server,
  client: configFromToml.client,
  database: configFromToml.database
} as const;
