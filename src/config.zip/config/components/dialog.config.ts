/**
 * @file        dialog.config.ts
 * @description Konfiguration für Dialog-Komponente (SEASIDE Dark Theme)
 * @version     0.3.0
 * @created     2025-12-11 01:00:23 CET
 * @updated     2025-12-12 19:50:18 CET
 * @author      Claude Code CLI
 *
 * @usage
 *   import { dialogConfig } from '@/config/components/dialog.config';
 *   const containerStyles = dialogConfig.container;
 *
 * @changelog
 *   0.3.0 - 2025-12-12 - Werte aus config.toml via Generator
 *   0.2.0 - 2025-12-11 - SEASIDE Dark Theme Farben
 *   0.1.0 - 2025-12-11 - Initial version
 */

import { appConfig } from '../load';

export const dialogConfig = appConfig.components?.dialog || { container: { className: '' } };
