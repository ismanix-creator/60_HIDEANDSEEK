/**
 * @file        button.config.ts
 * @description Konfiguration für Button-Komponente (SEASIDE Dark Theme)
 * @version     0.4.0
 * @created     2025-12-11 01:00:23 CET
 * @updated     2025-12-12 02:17:34 CET
 * @author      Claude Code CLI
 *
 * @usage
 *   import { buttonConfig } from '@/config/components/button.config';
 *   const styles = buttonConfig.variants.primary;
 *
 * @changelog
 *   0.4.0 - 2025-12-12 - Button variants now flow from config.toml generator
 *   0.3.0 - 2025-12-11 - size.xs für kompakte Panel-Buttons hinzugefügt
 *   0.2.0 - 2025-12-11 - SEASIDE Dark Theme Farben
 *   0.1.0 - 2025-12-11 - Initial version
 */

import { appConfig } from '../load';

export const buttonConfig = appConfig.components?.button || { variants: {}, sizes: {} };
