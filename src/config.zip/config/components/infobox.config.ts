/**
 * @file        infobox.config.ts
 * @description Konfiguration für Infobox-Komponente (SEASIDE Dark Theme)
 * @version     0.7.0
 * @created     2025-12-11 01:00:23 CET
 * @updated     2025-12-12 19:50:18 CET
 * @author      Claude Code CLI
 *
 * @usage
 *   import { infoboxConfig } from '@/config/components/infobox.config';
 *   const panelStyles = infoboxConfig.panel;
 *   const warningStyles = infoboxConfig.variants.warning;
 *
 * @changelog
 *   0.7.0 - 2025-12-12 - Werte aus config.toml via Generator
 *   0.6.1 - 2025-12-11 - formCompact.containerWidth von 60% auf 75% erhöht (+15%)
 *   0.6.0 - 2025-12-11 - Form-Elemente: Größe wie BAR/KOMBI Buttons (sm), Breite 66%, mehr Abstand
 *   0.5.0 - 2025-12-11 - Kompakte Form-Elemente (2/3 Größe) für Direktbuchung-Panel
 *   0.4.0 - 2025-12-11 - Spacing/Padding in echte REM-Werte konvertiert, responsive Widths
 *   0.3.0 - 2025-12-11 - Panel-Konfiguration für einheitliche Seitenpanels hinzugefügt
 *   0.2.0 - 2025-12-11 - SEASIDE Dark Theme Farben
 *   0.1.0 - 2025-12-11 - Initial version
 */

import { appConfig } from '../load';

export const infoboxConfig = appConfig.components?.infobox || { panel: {}, variants: {}, formCompact: {} };
