/**
 * @file        table.config.ts
 * @description Konfiguration für Table-Komponente (SEASIDE Dark Theme)
 * @version     0.5.0
 * @created     2025-12-11 01:00:23 CET
 * @updated     2025-12-12 20:05:02 CET
 * @author      Claude Code CLI
 *
 * @usage
 *   import { tableConfig } from '@/config/components/table.config';
 *   const headerStyles = tableConfig.header;
 *
 * @changelog
 *   0.5.0 - 2025-12-12 - Vollständig config.toml-basiert (wrapper/header/row/cell etc.)
 *   0.4.0 - 2025-12-12 - scrollContainer und sticky aus configFromToml
 *   0.3.0 - 2025-12-11 - bestandWeg und profitMultiline Spalten-Typen hinzugefügt
 *   0.2.0 - 2025-12-11 - SEASIDE Dark Theme Farben, erweiterte Konfiguration
 *   0.1.0 - 2025-12-11 - Initial version
 */

import { appConfig } from '../load';

export const tableConfig = appConfig.components?.table || {
  wrapper: { className: '' },
  scrollContainer: { className: '' },
  table: { className: '' },
  header: { className: '' },
  headerRow: { className: '' },
  headerCell: { className: '' },
  body: { className: '' },
  row: { className: '' },
  cell: { className: '' }
};

/** Page Header Buttons Konfiguration (aus TOML) */
export const pageHeaderConfig = appConfig.components?.pageHeader || {
  button: { className: '' }
};
