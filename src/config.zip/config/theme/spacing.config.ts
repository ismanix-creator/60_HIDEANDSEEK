/**
 * @file        spacing.config.ts
 * @description Derived Spacing Tokens mit Mobile Varianten (Source: config.toml)
 * @version     1.0.0
 * @created     2025-12-11 01:00:23 CET
 * @updated     2026-01-07 19:45:00 CET
 * @author      agenten-koordinator
 *
 * @changelog
 *   1.0.0 - 2026-01-07 - Refactored: config.toml SoT, derived tokens only
 */

import { appConfig } from '../load';

// Basis-Spacing aus config.toml (with fallback)
const baseSpacing = appConfig.theme?.spacing || {
  xxs: '0.125rem',
  xs: '0.25rem',
  sm: '0.5rem',
  md: '1rem',
  lg: '1.5rem',
  xl: '2rem',
  xxl: '3rem',
  layout: {
    contentMaxWidthRem: '100rem'
  },
  component: {
    button: {
      paddingX: { sm: '0.5rem', md: '1rem', lg: '1.5rem' },
      paddingY: { sm: '0.25rem', md: '0.5rem', lg: '0.75rem' }
    }
  }
};

export const spacingConfig = {
  // Alle Basis-Werte übernehmen
  ...baseSpacing,
  
  // Ensure base exists for components
  base: {
    xxs: baseSpacing.xxs,
    xs: baseSpacing.xs,
    sm: baseSpacing.sm,
    md: baseSpacing.md,
    lg: baseSpacing.lg,
    xl: baseSpacing.xl,
    xxl: baseSpacing.xxl
  },

  // Layout aus config.toml (with derived access)
  layout: baseSpacing.layout || {
    contentMaxWidthRem: '100rem'
  },

  // Component spacing aus config.toml
  component: baseSpacing.component || {
    button: {
      paddingX: { sm: '0.5rem', md: '1rem', lg: '1.5rem' },
      paddingY: { sm: '0.25rem', md: '0.5rem', lg: '0.75rem' }
    }
  },

  // Mobile-Varianten (kompakter für kleinere Screens)
  mobile: {
    xxs: '0.0625rem', // 1px
    xs: '0.125rem', // 2px
    sm: '0.25rem', // 4px
    md: '0.5rem', // 8px
    lg: '1rem', // 16px
    xl: '1.5rem' // 24px
  },

  // Responsive Layout-Werte
  responsive: {
    // Page Padding
    pagePadding: {
      mobile: '0.5rem', // 8px
      tablet: '1rem', // 16px
      desktop: '1.5rem' // 24px
    },
    // Content Gap
    contentGap: {
      mobile: '0.5rem', // 8px
      tablet: '1rem', // 16px
      desktop: '1rem' // 16px
    },
    // Bottom Navigation Höhe (Mobile)
    bottomNavHeight: '60px',
    // Bottom Navigation Padding (für Content-Offset)
    bottomNavPadding: '80px',
    // Sidebar Breite (Desktop)
    sidebarWidth: '200px'
  }
} as const;
