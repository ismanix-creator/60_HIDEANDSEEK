/**
 * @file        typography.config.ts
 * @description Derived Typography Tokens (Source: config.toml)
 * @version     1.0.0
 * @created     2025-12-11 01:00:23 CET
 * @updated     2026-01-07 19:45:00 CET
 * @author      agenten-koordinator
 *
 * @changelog
 *   1.0.0 - 2026-01-07 - Refactored: config.toml SoT, derived tokens only
 */

import { appConfig } from '../load';

export const typographyConfig = appConfig.theme?.typography || {
  fontFamily: { base: 'Segoe UI, system-ui, sans-serif', mono: 'JetBrains Mono, monospace' },
  fontSize: { xs: '0.75rem', sm: '0.875rem', md: '1rem', lg: '1.25rem', xl: '1.5rem' },
  fontWeight: { normal: 400, medium: 500, semibold: 600, bold: 700 }
};
