/**
 * @file        borderRadius.config.ts
 * @description Derived BorderRadius Tokens (Source: config.toml)
 * @version     1.0.0
 * @created     2025-12-11 01:00:23 CET
 * @updated     2026-01-07 19:45:00 CET
 * @author      agenten-koordinator
 *
 * @changelog
 *   1.0.0 - 2026-01-07 - Refactored: config.toml SoT, derived tokens only
 */

import { appConfig } from '../load';

export const borderRadiusConfig = appConfig.theme?.borderRadius || {
  none: '0',
  sm: '0.25rem',
  md: '0.5rem',
  lg: '1rem',
  full: '9999px'
};
