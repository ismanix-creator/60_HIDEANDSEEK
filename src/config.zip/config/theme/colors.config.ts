/**
 * @file        colors.config.ts
 * @description Derived Color Tokens (Source: config.toml)
 * @version     1.0.0
 * @created     2025-12-11 01:00:23 CET
 * @updated     2026-01-07 19:45:00 CET
 * @author      agenten-koordinator
 *
 * @changelog
 *   1.0.0 - 2026-01-07 - Refactored: config.toml SoT, derived tokens only
 */

import { appConfig } from '../load';

/**
 * Colors from config.toml (validated)
 * These are DIRECT exports, no hardcoded values
 */
export const colorsConfig = appConfig.theme?.colors || {
  // Emergency fallback (should never be reached due to schema validation)
  primary: { 50: '#e3f2fd', 100: '#bbdefb', 200: '#90caf9', 300: '#64b5f6', 400: '#42a5f5', 500: '#2196f3', 600: '#1e88e5', 700: '#1976d2', 800: '#1565c0', 900: '#0d47a1' },
  text: { primary: '#ffffff', secondary: '#cccccc', tertiary: '#999999' },
  ui: { background: '#1e1e1e', backgroundAlt: '#2d2d2d', border: '#3d3d3d' },
  button: { gray: '#3d3d3d', active: '#454545', customer: '#1f1f1f', offer: '#252525', order: '#303030', invoice: '#383838' },
  status: { error: '#e74c3c', warning: '#f39c12', success: '#27ae60', info: '#3498db' },
  error: { light: '#e74c3c', main: '#e74c3c', dark: '#c0392b' },
  warning: { light: '#f39c12', main: '#f39c12', dark: '#e67e22' },
  success: { light: '#27ae60', main: '#27ae60', dark: '#229954' },
  info: { light: '#3498db', main: '#3498db', dark: '#2980b9' },
  table: { stripe1: '#1a1a1a', stripe2: '#2a2a2a', selection: '#353535' }
};
