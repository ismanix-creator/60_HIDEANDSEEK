/**
 * @file        icons.config.ts
 * @description Derived Icon Tokens (Source: config.toml)
 * @version     1.0.0
 * @created     2025-12-12 00:34:07 CET
 * @updated     2026-01-07 19:45:00 CET
 * @author      agenten-koordinator
 *
 * @changelog
 *   1.0.0 - 2026-01-07 - Refactored: config.toml SoT, derived tokens only
 */

import { appConfig } from '../load';

export const iconsConfig = appConfig.theme?.icons || {
  sizes: { sm: '16px', md: '24px', lg: '32px', xl: '48px' }
};
