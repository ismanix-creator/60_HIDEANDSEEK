/**
 * @file        shadows.config.ts
 * @description Derived Shadow Tokens (Source: config.toml)
 * @version     1.0.0
 * @created     2025-12-11 01:00:23 CET
 * @updated     2026-01-07 19:45:00 CET
 * @author      agenten-koordinator
 *
 * @changelog
 *   1.0.0 - 2026-01-07 - Refactored: config.toml SoT, derived tokens only
 */

import { appConfig } from '../load';

export const shadowsConfig = appConfig.theme?.shadows || {
  sm: '0 1px 2px 0 rgba(0, 0, 0, 0.05)',
  md: '0 4px 6px -1px rgba(0, 0, 0, 0.1)',
  lg: '0 10px 15px -3px rgba(0, 0, 0, 0.1)',
  xl: '0 20px 25px -5px rgba(0, 0, 0, 0.1)',
  none: 'none'
};
