/**
 * @file        navigation.config.ts
 * @description Navigation Configuration (Pages und Icons)
 * @version     0.1.0
 * @created     2026-01-07 01:18:02 CET
 * @updated     2026-01-07 01:18:02 CET
 * @author      frontend-entwickler
 *
 * @usage
 *   import { navigationConfig } from '@/config/navigation.config';
 *
 * @changelog
 *   0.1.0 - 2026-01-07 - Initial version mit Gläubiger/Schuldner Navigation
 */

import type { NavItem } from '@/types/ui.types';

export const navigationConfig = {
  items: [
    {
      key: 'material',
      label: 'Material',
      path: '/',
      icon: 'package',
      adminOnly: false
    },
    {
      key: 'kunden',
      label: 'Kunden',
      path: '/kunden',
      icon: 'users',
      adminOnly: false
    },
    {
      key: 'glaeubiger',
      label: 'Gläubiger',
      path: '/glaeubiger',
      icon: 'arrow-down-circle',
      adminOnly: false
    },
    {
      key: 'schuldner',
      label: 'Schuldner',
      path: '/schuldner',
      icon: 'arrow-up-circle',
      adminOnly: false
    }
  ] as const satisfies readonly NavItem[]
} as const;
